const express= require('express');
const app = express();
const data = require('./data.json');




app.route('/events')
.get((req,res)=> {
    console.log(data);
res.json(data);
});

    



const port =process.env.PORT||3000;

app.listen (port ,() => console.log(`server strated on port ${port}`));